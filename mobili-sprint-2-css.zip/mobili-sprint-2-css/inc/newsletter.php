<!--NEWSLETTER-->
<section class="newsletter">
    <div class="container">
        <h3 class="alt-title">Suscribite al newsletter</h3>
        <p class="newsletter-info">Recibí nuestras ofertas y novedades directamente en tu e-mail.</p>
        <form action="#" method="post" class="form">
            <div class="form-item">
                <input type="email" name="email" placeholder="Ingrese su e-mail" required class="form-field" value="email">
            </div>
            <input type="submit" value="Enviar" class="submit-btn">
        </form>
    </div>
</section>
<!--END OF NEWSLETTER-->
