<!--CDN jQuery v3.3.1-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!--SLICK(SLIDER SCRIPTS)-->
<script type="text/javascript" src="js/vendor/slick.min.js"></script>
<!--JS CUSTOM-->
<script src="js/scripts.js"></script>
