<!--FOOTER-->
<footer>
    <div class="altMenu">
        <img src="img/logo-white.png" alt="Mobili Logo">
        <ul>
            <li><a href="#">Servicio al cliente</a></li>
            <li><a href="#">Nuestra empresa</a></li>
            <li><a href="preguntas-frecuentes.php">Preguntas frecuentes</a></li>
            <li><a href="#">Envios</a></li>
            <li><a href="#">Cambios y devoluciones</a></li>
        </ul>
    </div>
    <div class="copy">
        <p>2018&copy; Todos los derechos reservados.</p>
    </div>
</footer>
<!--END OF FOOTER-->
