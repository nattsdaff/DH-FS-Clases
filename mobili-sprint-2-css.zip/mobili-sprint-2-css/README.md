# m o b i l i

## V1 
Marketplace de muebles de diseño donde las tiendas pueden publicar sus productos
2 perfiles de usuario

-> admin
  
-> client

## V2

Apertura a tiendas oficiales

3 perfiles de usuario

-> admin
  
-> client

-> client
  
  
## Estructura de archivos

### Assets
Graphics, images & stuff


### Design
Editables


### Staging
Testing enviroment

-> css

-> img

-> js

### Production

Versión final 

-> css

-> img

-> js
